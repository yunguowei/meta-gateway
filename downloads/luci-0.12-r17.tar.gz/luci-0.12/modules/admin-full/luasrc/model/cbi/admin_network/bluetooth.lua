--[[
LuCI - Lua Configuration Interface

Copyright 2008 Steven Barth <steven@midlink.org>

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

$Id$
]]--
local util = require("luci.util")
local sys = require("luci.sys")
local uci = require "luci.model.uci".cursor()
local fs = require "nixio.fs"
local math = require "math"
local nx = require ("nixio")
local enable = false

function rewrite_config()
    local hcidevs = util.exec("ls /sys/class/bluetooth 2>/dev/null")
    local iname,ipageto,iscantype,istatus

    util.exec("rm /etc/config/bluetooth")
    util.exec("touch /etc/config/bluetooth")

    sys.exec("uci set bluetooth.daemon='general'")
    local pid_bluetoothd=sys.call("/usr/bin/pgrep bluetoothd > /dev/null 2>&1")
    if pid_bluetoothd == 0 then
	    sys.exec("uci set bluetooth.daemon.status='Running'")
    else
	    sys.exec("uci set bluetooth.daemon.status='Stopped'")
    end
    sys.exec("uci commit bluetooth")

    if sys.init.enabled("bluetooth") then
	enabled = true
    end

    if hcidevs then
        for dev in hcidevs:gmatch("%S+") do
            status = util.exec("hciconfig " .. dev .. " | grep 'UP RUNNING'")
            sec = sys.exec("uci add bluetooth hciconfig")
            sys.exec("uci commit bluetooth")
            sec = string.sub(sec,0,9)
            if status:find("UP RUNNING") then
                iname = util.exec("hciconfig " .. dev .. " name | grep Name: | awk '{print $2}' | sed \"s/\'//g\"")
                ipageto = sys.exec("hciconfig " .. dev .. " pageto|grep 'Page timeout:'|awk '{print $3}' | sed \"s/\'//g\"")
                iscantype = "noscan"
                p_scan = sys.exec("hciconfig $device | grep 'PSCAN'")
                i_scan = sys.exec("hciconfig $device | grep 'ISCAN'")
                pi_scan = sys.exec("hciconfig $device | grep 'PSCAN ISCAN'")
                if i_scan:find("ISCAN") then
                    iscantype = "iscan"
                end
                if p_scan:find("PSCAN") then
                    iscantype = "pscan"
                end
                if pi_scan:find("PSCAN ISCAN") then
                   iscantype = "piscan"
                end
                if sec then
                   sys.exec("uci set bluetooth." .. sec ..  ".device=" .. dev)
                   sys.exec("uci set bluetooth." .. sec ..  ".name=" .. iname)
                   sys.exec("uci set bluetooth." .. sec ..  ".pageto=" .. ipageto)
                   sys.exec("uci set bluetooth." .. sec ..  ".scantype=" .. iscantype)
                   sys.exec("uci set bluetooth." .. sec ..  ".status=UP")
               end
           else
               if sec then
                   sys.exec("uci set bluetooth." .. sec .. ".device=" .. dev)
                   sys.exec("uci set bluetooth." .. sec .. ".status=DOWN")
               end
           end
        end
           sys.exec("uci commit bluetooth")
   end
end
rewrite_config()

m = Map("bluetooth", translate("Bluetooth"))
m.anonymous = true

daemon = m:section(TypedSection, "general", translate("Bluetooth Daemon Status"))
daemon.anonymous = true

local enabled = false
if sys.init.enabled("bluetooth") then
	enabled = true
end

local pid_bluetoothd=sys.call("/usr/bin/pgrep bluetoothd > /dev/null 2>&1")
if pid_bluetoothd == 0 then
	m.uci:set("bluetooth", "daemon", "status", "Running")
else
	m.uci:set("bluetooth", "daemon", "status", "Stopped")
end
m.uci:commit("bluetooth")

daemon_status = daemon:option(DummyValue, "status", translate("Bluetooth Deamon Status"))
dbtn = daemon:option(Button, "enable", translate(" "))
function dbtn.render(self, section, scope)
	if enabled then
		self.inputtitle = translate("Disable")
		self.inputstyle = "apply"
	else
	        self.inputtitle = translate("Enable")
		self.inputstyle = "apply"
	end
	Button.render(self, section, scope)
end

function dbtn.write(self, section, value)
	if not enabled then
		sys.init.enable("bluetooth")
		sys.init.start("bluetooth")

                --Map to bt internal config to uci config
                if fs.access("/etc/config/bluetooth") then
                    local hci_devs = util.exec("ls /sys/class/bluetooth 2>/dev/null")
                    local uci_name,uci_pageto,uci_scantype,uci_status

                    if hci_devs then
                        for dev in hci_devs:gmatch("%S+") do
                            s_name=util.exec("hciconfig " .. dev .. " name | grep Name: | awk '{print $2}' | sed \"s/\'//g\"")
                            s_pageto = sys.exec("hciconfig " .. dev .. " pageto|grep 'Page timeout:'|awk '{print $3}' | sed \"s/\'//g\"")

                            s_scantype = "noscan"
                            p_scan = sys.exec("hciconfig $device | grep 'PSCAN'")
                            i_scan = sys.exec("hciconfig $device | grep 'ISCAN'")
                            pi_scan = sys.exec("hciconfig $device | grep 'PSCAN ISCAN'")
                            if p_scan:find("PSCAN") then
                                s_scantype = "pscan"
                            end
                            if i_scan:find("ISCAN") then
                                s_scantype = "iscan"
                            end
                            if pi_scan:find("PSCAN ISCAN") then
                                s_scantype = "piscan"
                            end

                            local sec
                            m.uci:foreach("bluetooth", "hciconfig",
                                function(s)
                                    if s['device'] == dev then
                                        sec = s['.name']
                                    end
                                end)
                            if sec then
                                uci:set("bluetooth", sec, "name", s_name)
                                uci:set("bluetooth", sec, "pageto", s_pageto)
                                uci:set("bluetooth", sec, "scantype", s_scantype)
                                uci:commit("bluetooth")
                            end
                       end
                    end
                end
	else
		sys.init.stop("bluetooth")
		sys.init.disable("bluetooth")
	end
	luci.http.redirect(luci.dispatcher.build_url(
	"admin", "network", "bluetooth"
	))
end

sc = m:section(TypedSection, "hciconfig", translate("Config Bluetooth Device"))
sc.anonymous = true

status = sc:option(ListValue, "status", translate("Bluetooth Device Status"))
status:value("DOWN", translate("DOWN"))
status:value("UP", translate("UP"))
status.default = "DOWN"

name = sc:option(Value, "name", translate("Bluetooth Device Name"))
name.datatype = "hostname"

pageto = sc:option(Value, "pageto", translate("Page Timeout"))
pageto.datatype = "uinteger"

scantype = sc:option(ListValue, "scantype", translate("Scan Type"))
scantype:value("piscan", translate("piscan"))
scantype:value("pscan", translate("pscan"))
scantype:value("iscan", translate("iscan"))
scantype:value("noscan", translate("noscan"))
scantype.default = "pscan"

ap = sc:option(Button, "Apply", translate(" "))
ap.inputtitle = translate("Apply Config")
ap.inputstyle = "reload"

function valid_name(val)
  if val and (#val < 254) and (
    val:match("^[a-zA-Z_]+$") or
    (val:match("^[a-zA-Z0-9_][a-zA-Z0-9_%-%.]*[a-zA-Z0-9]$") and
    val:match("[^0-9%.]"))
    ) then
      return true
    end
    return false
end

function valid_page_timeout(val)
    local n = tonumber(val)
    if n ~= nil and math.floor(n) == n and n >= 0 then
        return true
    end
    return false
end

function ap.write(self, section, value)
        local device = m.uci:get("bluetooth", section, "device")
        local status_v = status:formvalue(section)
        local name_v = name:formvalue(section)
        local pageto_v = pageto:formvalue(section)
        local scantype_v = scantype:formvalue(section)

	if status_v and status_v == "UP" then
                util.exec("hciconfig " .. device .. " up")
                util.exec("echo 'PRETTY_HOSTNAME=" .. name_v .. "' > /etc/machine-info")
                if sys.exec("hciconfig " .. device .. "|grep 'UP RUNNING'") then
                    m:set(section, "status", "UP")
                end

                if valid_name(name_v) then
                    util.exec("hciconfig " .. device .. " name " .. name_v)
                    newname=sys.exec("hciconfig " .. device .. " name|grep Name: | awk '{print $2}' | sed s/\'//g")
                    if newname == name_v then
                        m:set(section, "name", name_v)
                    end
                end

                if valid_page_timeout(pageto_v) then
                    util.exec("hciconfig " .. device .. " pageto " .. pageto_v)
                    newpageto=sys.exec("hciconfig " .. device .. " pageto|grep 'Page timeout:'|awk '{print $3}' | sed s/\'//g")
                    if newpageto == pageto_v then
                        m:set(section, "pageto", pageto_v)
                    end
                end

                util.exec("hciconfig " .. device .. " " .. scantype_v)
                if sys.exec("hciconfig " .. device .. " |grep " .. scantype_v) then
                    m:set(section, "scantype", scantype_v)
                end
        else
            util.exec("hciconfig " .. device .. " down")
            if sys.exec("hciconfig " .. device .. "|grep 'DOWN'") then
                m:set(section, "status", "DOWN")
            end
	end
        m.uci:commit("bluetooth")
	luci.http.redirect(luci.dispatcher.build_url(
	  "admin", "network", "bluetooth"
	  ))
end

f = SimpleForm("bluetooth", translate(""))
f.reset  = false
f.submit = false
y = f:section(SimpleSection, translate("Scan Bluetooth Devices Around"))
p = y:option(Button, "scan", translate("Scan Devices"))
p.inputtitle = translate("Scan")
p.inputstyle = "reload"

local scanfile = "/tmp/.luci-btscan"
local devices = {}
local ds = util.exec("cat "..scanfile.." 2>/dev/null && rm -f "..scanfile)
for i,v in ipairs(util.split(ds)) do
	if not v:match("^Scanning") then
		local a,d = v:match("%s+(%S+)%s+(%S+)")
		devices[i] = {
			['Address']   = a,
			['Device']    = d
		}
	end
end
function p.write(self, section, value)
	util.exec("hcitool scan >"..scanfile)
	luci.http.redirect(luci.dispatcher.build_url(
		"admin", "network", "bluetooth"
	))
end

t = f:section(Table, devices, "")
a = t:option(DummyValue, "Device", translate("Device"))
b = t:option(DummyValue, "Address", translate("Address"))

local hs = util.exec("ls /sys/class/bluetooth")
local hcis = {}
for i,v in ipairs(util.split(hs, "%s+", 32, true)) do
	if v != "" then
		local status = util.exec("hciconfig -a "..v):gsub(v..":", ""):gsub("\n", "<br/>")
		status = status:gsub("(UP)", "<b>%1</b>")
		status = status:gsub("(DOWN)", "<b>%1</b>")
		local action = "Down"
		if status:match("DOWN") then action = "Up" end
                local page_to= util.exec("hciconfig "..v.." pageto | grep 'Page timeout:'")
                status = status .. page_to
		hcis[i] = {
			['Device']    = v,
			['Status']    = status
			--['Action']    = action
		}
	end
end

t = f:section(Table, hcis, translate("Bluetooth Device Information"))
a = t:option(DummyValue, "Device", translate("Device"))
b = t:option(DummyValue, "Status", translate("Status"))
b.rawhtml = true

return m,f
