COPY_FILES="/etc/firewall.config
/etc/firewall.user
/etc/httpd.conf
/etc/hosts
/etc/ethers"

COPY_DIRS="/etc/config
/etc/openvpn
/etc/crontabs
/etc/ssl
/etc/dropbear"


tmp=/tmp/config.$$
tgz=/tmp/wridp-backup.tgz

rm -rf $tmp $tgz 2>/dev/null

mkdir -p $tmp 2>/dev/null
date > $tmp/config.date

cat /etc/device_name > $tmp/config.boardtype

for file in $COPY_FILES; do
	[ -e $file ] && [ ! -h $file ] && {
	d=`dirname $file`; [ -d $tmp$d ] || mkdir -p $tmp$d
	cp -af $file $tmp$file 2>/dev/null
	}
done
for dir in $COPY_DIRS; do
	[ -e $dir ] && {
	mkdir -p $tmp$dir
	cp -afr $dir/* $tmp$dir/ 2>/dev/null
	}
done
#[ -n "$tmp" ] && rm $tmp/etc/banner
(cd $tmp; tar czf $tgz *;)
# ln -s $tgz /www/${FORM_name:-config}.tgz)

rm -rf $tmp 2>/dev/null

