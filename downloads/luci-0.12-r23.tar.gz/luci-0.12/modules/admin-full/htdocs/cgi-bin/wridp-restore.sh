dir=/tmp/configs-tmp
archive=/tmp/wridp-restore.tgz
ARCHIVE_DELETE=/tmp/wridp-restore.tgz.delete

echo $dir
if [ -d "$dir" ]; then
	rm -rf $dir
fi

mkdir -p $dir

if [ -e "$archive" ] && [ -d "$dir" ]; then
	tar -C $dir -zxvf $archive

	if [ -e "$ARCHIVE_DELETE" ]; then
		rm $archive-delete
	fi
	mv -f $archive $ARCHIVE_DELETE
fi

#if [ -n "$dir" ] && [ -d "$dir" ] && [ -e "$dir/config.name" ] && [ -e "$dir/config.boardtype" ]; then
if [ -n "$dir" ] && [ -d "$dir" ] && [ -e "$dir/config.date" ] && [ -e "$dir/config.boardtype" ]; then
		cd $dir
		for file in $(find etc); do
			if [ -d $file ]; then
				[ -d /$file ] || mkdir /$file
			else
				[ -e /$file ] && rm /$file
				cp -af $file /$file
			fi
		done

		rm -rf $dir

		echo "Succeed to restore"

else
	echo "Failed to restore"
fi


